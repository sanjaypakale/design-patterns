package com.javatechie.solid.isp;

public interface UPIPayments {

    public void payMoney();

    public void getScratchCard();


}
