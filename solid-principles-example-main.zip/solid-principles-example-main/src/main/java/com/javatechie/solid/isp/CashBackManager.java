package com.javatechie.solid.isp;

public interface CashBackManager {

    public void getCashBackAsCreditBalance();
}
